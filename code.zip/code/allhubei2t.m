function [Syiih, xinzegnh, IC1,IC2, IC3]= allhubei2t(Bqs, I2,ce1, startdate, N1h,  Bq1,Bq2,Bq4, B21hubei,leijiganran, E1h, Syiih,S1h,I1h, xinzegnh)

[sd1,sd2] = size(N1h);

   
I1h(startdate) = leijiganran(startdate) + I2  ;   
% I2h(startdate) =  I2  ;   
E1h(startdate) = ce1 ;
Syiih(startdate) = leijiganran(startdate);
S1h(startdate) = N1h(startdate) -  E1h(startdate)- I1h(startdate);  
xinzegnh(startdate) = leijiganran(startdate);
% xinzegnh2 = xinzegnh + I2;
% yyyh =  1/Dq1hubei;            %ȥҽԺ���� 
  IC1(startdate)  = leijiganran(startdate);
  IC2(startdate) = 0;
   IC3(startdate) = 0;
B2h = B21hubei;   
a = 1/5.2;                                                                 
%  sd1 = 60;
cc = 0;
Bq2eaac = Bq2;
for idx = startdate:1:sd1-1 
%       if idx>12
%       Bq2 = Bq2eaac*1.5;      
%      end
      S1h(idx+1) = S1h(idx) - B2h* S1h(idx)*I1h(idx)/N1h(idx)- B2h* S1h(idx)*E1h(idx)/N1h(idx)* Bqs;    
      E1h(idx+1) = E1h(idx) +  B2h* S1h(idx)*I1h(idx)/N1h(idx) + B2h* S1h(idx)*E1h(idx)/N1h(idx)* Bqs - a*E1h(idx) - Bq2 * E1h(idx) - Bq4 * E1h(idx) ;    
    
      I1h(idx+1) = I1h(idx) + a*E1h(idx)   - Bq1*I1h(idx)  - Bq2 * I1h(idx)  ;   
      
%       if I2h(idx+1)<0
%           I2h(idx+1) = 0;
%       end
         
            xinzegnh(idx+1) =   Bq1*I1h(idx) + Bq2 * I1h(idx)   +  Bq2 * E1h(idx) +  Bq4 * E1h(idx)  ;     
     Syiih(idx+1)=   Syiih(idx)  +    xinzegnh(idx+1); 
          IC1(idx+1)   = IC1(idx) + Bq1*I1h(idx) ;
  IC2(idx+1)  = IC2(idx) + Bq2 * I1h(idx) + Bq2 * E1h(idx);
   IC3(idx+1)  = IC3(idx) +    Bq4 * E1h(idx) ;
     N1h(idx+1) = N1h(idx);    
     
end
xinzegnh(startdate) = leijiganran(startdate);
end
   