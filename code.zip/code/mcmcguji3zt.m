function  [B1hubeifin,bq1hubeifin,bq2hubeifin,bq4hubeifin,ceqfum,I2hubeifin]= mcmcguji3t( )
load ruoeyu.mat
[c1,c2] = size(B1hubeifin)
B1hubeifin = B1hubeifin(c1*3/4:c1);
bq1hubeifin = bq1hubeifin(c1*3/4:c1);
bq2hubeifin = bq2hubeifin(c1*3/4:c1);
bq4hubeifin = bq4hubeifin(c1*3/4:c1);
ceqfum = ceqfum(c1*3/4:c1);
I2hubeifin = I2hubeifin(c1*3/4:c1);
end
 
 
