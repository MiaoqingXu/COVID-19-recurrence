function   mcmcguji2( datachina,Bqs,three )
tic; 
[sd2,sd3] = size(datachina);
Ileiji1 = zeros( sd2, 2);
Ileiji1(:,1) = datachina(:);
Ileiji1(:,2) = datachina(:);
  
mcleng = floor(24000);  
B1hubeifin = zeros(mcleng , 1);
I2hubeifin= zeros(mcleng , 1); 
ceqfum = zeros(mcleng,1);
bq1hubeifin = zeros(mcleng,1);
bq2hubeifin = zeros(mcleng,1);
bq4hubeifin = zeros(mcleng,1);
remsess = zeros(mcleng ,1 );
  
leijiganran = Ileiji1(:,1);
xinzengganran = Ileiji1(:,2);
tianshu = leijiganran(leijiganran>0);
startdate0 = sd2 - length(tianshu) + 1;
 
N1hubei =  zeros(sd2, 1);
N1hubei(startdate0) = 21536000;           
  
E1hubei = zeros(sd2, 1);
Syiihubei = zeros(sd2, 1);
S1hubei = zeros(sd2, 1);
I1hubei = zeros(sd2, 1); 
xinzegnhubei = zeros(sd2, 1);
 
mcn = 1; 
B21hubeiraw = unifrnd(0,1);
Bq1hubeiraw = unifrnd(0.25,0.5);
Bq2hubeiraw = unifrnd(0,0.5); 
Bq4hubeiraw = unifrnd(0,0.5);
ce1raw = unifrnd(20,200);
I2raw = unifrnd(20,50);
likehoodraw =sum(log(ones(sd2+200,1)*1e-168));
 
for mcmcnum = 1:mcleng     
B21hubei =  ernormrnd(B21hubeiraw,1.5  /10,0,1.5);    
Bq1 = ernormrnd(Bq1hubeiraw,0.25/10,0.25,0.5);  
Bq2 = ernormrnd(Bq2hubeiraw,0.5/10,0,0.5);   
Bq4 = ernormrnd(Bq4hubeiraw,0.5/10,0,0.5);
ce1 = ernormrnd(ce1raw,180/10,20,200); 
I2 =  ernormrnd(I2raw,30/10,20,50);  
ce1 = floor(ce1);
I2 = floor(I2);

[Syiih, xinzegnh, I1cc, I2CC,I3CC]= allhubei2t( Bqs, I2, ce1, startdate0,  N1hubei,  Bq1, Bq2, Bq4, B21hubei,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);
 

likehoodhubei = poisspdf( xinzengganran(startdate0:sd2), xinzegnh(startdate0:sd2));
likehoodhubei3 = log( poisspdf( 81, I1cc(13) )+ 1e-168);
likehoodhubei4 = log( poisspdf(137, I2CC(13) )+ 1e-168);
likehoodhubei5 = log( poisspdf(38, I3CC(13))+ 1e-168); 
dsuo = [38,81,137]; 
dio = sum(three(:,2:8),2);
dio = dio + dsuo';
deuuy = [ I3CC(20); I1cc(20); I2CC(20);];
likehoodhubeiful = sum(sum(log( poisspdf( dio, deuuy)+ 1e-168)));
likehood2 = sum(log(likehoodhubei + 1e-168)) + likehoodhubei3  + likehoodhubei4 +likehoodhubei5+likehoodhubeiful ; 
arfea = likehood2 - likehoodraw;
if arfea > log(1)
ce1raw = ce1;
B21hubeiraw =  B21hubei;  
Bq1hubeiraw = Bq1;
Bq2hubeiraw = Bq2; 
Bq4hubeiraw = Bq4;
I2raw = I2;
likehoodraw = likehood2;
else
uy = log(unifrnd(0,1))* 10 ;
if uy < arfea  
mcn = mcn + 1;
B21hubeiraw =  B21hubei;  
ce1raw = ce1;
I2raw = I2;
Bq1hubeiraw = Bq1;
Bq2hubeiraw = Bq2;
Bq4hubeiraw = Bq4; 
likehoodraw = likehood2;
end
end
I2hubeifin(mcmcnum) = I2raw;
B1hubeifin(mcmcnum) = B21hubeiraw;
bq1hubeifin(mcmcnum) = Bq1hubeiraw;
bq2hubeifin(mcmcnum) = Bq2hubeiraw;
bq4hubeifin(mcmcnum) = Bq4hubeiraw;
ceqfum(mcmcnum) = ce1raw;
remsess(mcmcnum) = likehood2;
end
toc;


[b1b,b1f,B21hubeiraw] =  zhixing( B1hubeifin);
[q1b,q1f,bq1hubeiraw] =  zhixing( bq1hubeifin  );
[q2b,q2f,bq2hubeiraw] =  zhixing( bq2hubeifin  );
[q4b,q4f,bq4hubeiraw] =  zhixing( bq4hubeifin  );
[e1b,e1f,ce1raw] =  zhixing( ceqfum );
[i1b,i1f,I2raw] =  zhixing( I2hubeifin );
ce1raw = floor(ce1raw);
I2raw = floor(I2raw);

[Syiih, xinzegnh, I1cc, I2CC,I3CC]= allhubei2t( Bqs,I2raw, ce1raw, startdate0,  N1hubei, bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);
  
save ruoeyu.mat
end
 
 
 

 function [pred, bej, med2] = zhixing(dsu)
 [sd2,sd3] = size(dsu);
dsu = dsu(sd2*3/4:sd2);
med = mean(dsu);
msd = std(dsu);
pred = med - 1.96 * msd;
bej = med + 1.96  * msd;
med2 = median(dsu);
 end
  

function [c] = ernormrnd(cE1raw,sigma,a,b)
c = normrnd(cE1raw,sigma);
while c < a || c > b
      c = normrnd(cE1raw,sigma);
end 
end
