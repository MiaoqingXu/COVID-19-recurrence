clear;
%read data
fileNames = 'dailycase.xlsx';
datachina=xlsread(fileNames);  
fileNames = 'threekinds.xlsx';
three=xlsread(fileNames)';  
 
%model fitting
 B1hubeifins = [];
 bq1hubeifins= [];
 bq2hubeifins= [];
 bq4hubeifins= [];
 ceqfums= [];
 I2hubeifins= [];
 %  the ratio of the transmission rate of incubatory COVID-19 cases to the transmission rate of confirmed COVID-19 cases. 
 Bqs = 0.5;
for i = 1:50
mcmcguji2(datachina,Bqs ,three) ; 
[B1hubeifin,bq1hubeifin,bq2hubeifin,bq4hubeifin,ceqfum,I2hubeifin]= mcmcguji3zt();
B1hubeifins=[B1hubeifins;B1hubeifin];
bq1hubeifins=[bq1hubeifins;bq1hubeifin];
bq2hubeifins=[bq2hubeifins;bq2hubeifin];
bq4hubeifins=[bq4hubeifins;bq4hubeifin];
ceqfums=[ceqfums;ceqfum];
I2hubeifins=[I2hubeifins;I2hubeifin];
end
sudoi = 0;
save all100.mat
%output
mcmcguji3t(Bqs)

 
 
