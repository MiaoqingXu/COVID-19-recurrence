function  [dipos,zhisuy,muuiq3,rmuui1,rmuui2]= mcmcguji3t( Bqs)
load ruoeyu.mat
load all100.mat

B1hubeifin = B1hubeifins; 
bq1hubeifin =   bq1hubeifins;
bq2hubeifin= bq2hubeifins;
bq4hubeifin = bq4hubeifins;
ceqfum =  ceqfums ;
I2hubeifin = I2hubeifins ;
% meadian and 95%CI
[b1b,b1f,B21hubeiraw] =  zhixing( B1hubeifins);
[q1b,q1f,bq1hubeiraw] =  zhixing( bq1hubeifins  );
[q2b,q2f,bq2hubeiraw] =  zhixing( bq2hubeifins  );
[q4b,q4f,bq4hubeiraw] =  zhixing( bq4hubeifins  );
[e1b,e1f,ce1raw] =  zhixing( ceqfums );
[i1b,i1f,I2raw] =  zhixing( I2hubeifins );
ce1raw = floor(ce1raw);
I2raw = floor(I2raw);
 
 

days = 55;
 %Rc
Bqcs =  Bqs;
muui = B1hubeifin/5.2./(bq1hubeifin)./(1/5.2)+B1hubeifin*Bqcs./(1/5.2);
[m1b2,m1f2,rmuui1] =  zhixing( muui);
 %Re
muui = B1hubeifin/5.2./(bq1hubeifin+bq2hubeifin)./(bq4hubeifin+bq2hubeifin+1/5.2)+B1hubeifin*Bqcs./(bq4hubeifin+bq2hubeifin+1/5.2);
[m1b,m1f,rmuui2] =  zhixing( muui);

%Q2
bq2hubeirawc = bq2hubeiraw;
muuiq1 = B21hubeiraw/5.2./(bq1hubeiraw+bq2hubeirawc)./(bq4hubeiraw+bq2hubeirawc+1/5.2)+B21hubeiraw*Bqcs./(bq4hubeiraw+bq2hubeirawc+1/5.2);
muuiq2 = B21hubeiraw/5.2./(bq1hubeiraw)./(bq4hubeiraw+1/5.2)+B21hubeiraw*Bqcs./(bq4hubeiraw+1/5.2);
muuiq3 = muuiq1/muuiq2;
%Q1
muuiq1 = B21hubeiraw/5.2./(bq1hubeiraw+bq2hubeirawc)./(bq4hubeiraw+bq2hubeirawc+1/5.2)+B21hubeiraw*Bqcs./(bq4hubeiraw+bq2hubeirawc+1/5.2);
muuiq2 = B21hubeiraw/5.2./(bq1hubeiraw)./(1/5.2)+B21hubeiraw*Bqcs./(1/5.2);
muuiq32 = muuiq1/muuiq2;

%  test number when R=1
dydi = zeros(10000,1);
for i=1:10000
    bq2hubeirawc = bq2hubeiraw * i/10000;
    muuiq1 = B21hubeiraw/5.2./(bq1hubeiraw+bq2hubeirawc)./(bq4hubeiraw+bq2hubeirawc+1/5.2)+B21hubeiraw*Bqcs./(bq4hubeiraw+bq2hubeirawc+1/5.2);
    dydi(i)=abs(muuiq1-1);
end
[a,b] = min(dydi);
bq2hubeirawc = bq2hubeiraw * b/10000 * 29.4/bq2hubeiraw;
muuiq1 = B21hubeiraw/5.2./(bq1hubeiraw+bq2hubeirawc)./(bq4hubeiraw+bq2hubeirawc+1/5.2)+B21hubeiraw*Bqcs./(bq4hubeiraw+bq2hubeirawc+1/5.2);
bq2hubeirawc33 = bq2hubeiraw * b/10000 * 29.4/bq2hubeiraw;

  %fitting line
[Syiih, xinzegnh, IC1,IC2, IC3, IC21,IC22]= allhubei2tt(Bqs, days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);

xinzegnh(xinzegnh<1)=0;
enddata = 0;
for i = 1:55
    if xinzegnh(i)<1
      enddata = i;
    break
    end
end
T = 1:length(xinzegnh);
T2 = 1:length(xinzengganran);
sdsip = xinzegnh;
sdsip(1:21)=xinzengganran;
sdyoj = zeros(55,1);
sdyoj(1)=1;
for i = 1:55
    sdyoj(i+1) = sdyoj(i)+sdsip(i);
end
dsyoi = sdyoj(enddata);
% 
figure;
plot( T,xinzegnh, T2,xinzengganran','LineWidth',2)
 enddata=51;

zhiecu1 = [Syiih(enddata), xinzegnh(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];

 %different test number 
bq2hubeirawc = bq2hubeiraw;
bq2hubeiraw = bq2hubeirawc * 4000/295000;

[Syiih2, xinzegnh2, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);
zhiecu2 = [Syiih2(enddata), xinzegnh2(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];

 bq2hubeiraw = bq2hubeirawc * 25000/295000;

[Syiih3, xinzegnh3, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);
zhiecu3 = [Syiih3(enddata), xinzegnh3(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];


 bq2hubeiraw = bq2hubeirawc * 40000/295000;

[Syiih41, xinzegnh41, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);
zhiecu41 = [Syiih41(enddata), xinzegnh41(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];


 bq2hubeiraw = bq2hubeirawc * 90000/295000;

[Syiih4, xinzegnh4, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);
zhiecu5 = [Syiih4(enddata), xinzegnh4(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];

 bq2hubeiraw = bq2hubeirawc * 200000/295000;

[Syiih5, xinzegnh5, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);



zhiecu6 = [Syiih5(enddata), xinzegnh5(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];



 bq2hubeiraw = bq2hubeirawc * 270000/295000;

[Syiih6, xinzegnh6, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);

  
zhiecu7 = [Syiih6(enddata), xinzegnh6(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];


 bq2hubeiraw = bq2hubeirawc * 0/295000;

[Syiih7, xinzegnh7, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);

  
zhiecu8 = [Syiih7(enddata), xinzegnh7(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];


 bq2hubeiraw = bq2hubeirawc * bq2hubeirawc33*10000/295000;

[Syiih8, xinzegnh8, IC1,IC2, IC3, IC21,IC22 ]= allhubei2tt( Bqs,days, I2raw, ce1raw, startdate0,  N1hubei,  bq1hubeiraw, bq2hubeiraw, bq4hubeiraw, B21hubeiraw,leijiganran, E1hubei, Syiihubei,S1hubei,I1hubei,xinzegnhubei);

  
zhiecu9 = [Syiih8(enddata), xinzegnh8(enddata), IC1(enddata), IC2(enddata) ,IC3(enddata),IC21(enddata),IC22(enddata) ];


zhisuy =[zhiecu1;zhiecu2;zhiecu3;zhiecu41;zhiecu5;zhiecu6;zhiecu7;zhiecu8;zhiecu9];

sudo = 1/bq1hubeiraw;
T = 1:length(xinzegnh);
T2 = 1:length(xinzengganran);

figure;
plot( T,xinzegnh, T,xinzegnh5, T,xinzegnh6,    T,xinzegnh8, T2,xinzengganran','LineWidth',2)
figure;
plot(  T,xinzegnh2, T,xinzegnh3,    T,xinzegnh41, T,xinzegnh4,'LineWidth',2)

end
 

 

 function [pred, bej, med2] = zhixing(dsu)
 [sd2,sd3] = size(dsu);
% dsu = dsu(sd2*3/4:sd2);
med = mean(dsu);
msd = std(dsu);
pred = med - 1.96 * msd;
bej = med + 1.96  * msd;
med2 = median(dsu);
 end
  

function [c] = ernormrnd(cE1raw,sigma,a,b)
c = normrnd(cE1raw,sigma);
while c < a || c > b
      c = normrnd(cE1raw,sigma);
end 
end
